# Contributor Covenant Code of Conduct
Please refer to our HiveMQ [Code of Conduct](https://github.com/hivemq/hivemq-community/blob/master/code-of-conduct.md).
